package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class QuizActivity extends AppCompatActivity{

    TextView textViewWelcome, textViewQuestion, textViewPage, textViewQNo;
    Button ansButton1, ansButton2, ansButton3 , nextButton;
    ProgressBar progressBar;
    int score = 0;
    int totalq = 5;
    int page = 1;
    int answered = 0;
    int optchosen;
    String name;

    ArrayList<String> QuestionNo = new ArrayList<String>();
    ArrayList<String> Questions = new ArrayList<String>();
    ArrayList<String[]> Answers = new ArrayList<String[]>();
    ArrayList<int[]> CorrectAnswers = new ArrayList<int[]>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        textViewWelcome = findViewById(R.id.textViewWelcome);
        textViewPage = findViewById(R.id.textViewPage);
        textViewQuestion = findViewById(R.id.textViewQuestion);
        textViewQNo = findViewById(R.id.textViewQNo);
        ansButton1 = findViewById(R.id.ansButton1);
        ansButton2 = findViewById(R.id.ansButton2);
        ansButton3 = findViewById(R.id.ansButton3);
        progressBar = findViewById(R.id.progressBar);

        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        textViewWelcome.setText("Welcome " + name + "!" );
        progressBar.setMax(totalq);

        QuestionNo.add("Q1");
        Questions.add("What is the programming language used to develop this app?");

        Answers.add(new String[]{"C++","Java","JavaScript"});
        CorrectAnswers.add(new int[]{0,1,0});

        QuestionNo.add("Q2");
        Questions.add("Intent is used for ______");

        Answers.add(new String[]{"Requesting information from other components","Closing the app","Printing data"});
        CorrectAnswers.add(new int[]{1,0,0});

        QuestionNo.add("Q3");
        Questions.add("What is a spinner used for in Android Studio?");

        Answers.add(new String[]{"Creating a textbox","Display a dropdown list","To change the orientation"});
        CorrectAnswers.add(new int[]{0,1,0});

        QuestionNo.add("Q4");
        Questions.add("What does API stand for?");

        Answers.add(new String[]{"Application Processing Interface","Application Programming Interface","Apple Processing Interface"});
        CorrectAnswers.add(new int[]{0,1,0});

        QuestionNo.add("Q5");
        Questions.add("Which of the following platform is used in this Unit?");

        Answers.add(new String[]{"Skype","DeakinTalent","OnTrack"});
        CorrectAnswers.add(new int[]{0,0,1});

        progressBar.setProgress(page - 1);
        textViewPage.setText(page + "/" + totalq);

        Options();
    }

    public void OnClickSubmit(View view) {

        nextButton = (Button)view;
        String buttonText = nextButton.getText().toString();

        if (buttonText.equals("Submit")){

            if (optchosen == 0){
                Checker(0, ansButton1);
            }
            else if (optchosen == 1){
                Checker(1, ansButton2);
            }
            else if (optchosen == 2){
                Checker(2, ansButton3);
            }

            nextButton.setText("Next");
        }
        else{
            if (page + 1 > totalq) {

                Intent intent = new Intent(this, FinalActivity.class);
                intent.putExtra("Name", totalq);
                intent.putExtra("Score", score);
                intent.putExtra("MaxQuestions", totalq);

                startActivity(intent);
                finish();
            }
            else{
                page += 1;
                progressBar.setProgress(page - 1);
                textViewPage.setText(page + "/" + totalq);
                nextButton.setText("Submit");

                Options();
            }
        }
    }



    public void OnClickAnsOne(View view){
        ansButton1.setBackgroundColor(Color.BLUE); //yellow
        optchosen = 0;

    }

    public void OnClickAnsTwo(View view){
        ansButton2.setBackgroundColor(Color.BLUE); //yellow
        optchosen = 1;

    }
    public void OnClickAnsThree(View view){
        ansButton3.setBackgroundColor(Color.BLUE); //yellow
        optchosen = 2;

    }
    private void Options() {
        int current = page - 1;
        textViewQNo.setText(QuestionNo.get(current));
        textViewQuestion.setText(Questions.get(current));
        ansButton1.setText(Answers.get(current)[0]);
        ansButton2.setText(Answers.get(current)[1]);
        ansButton3.setText(Answers.get(current)[2]);

        ansButton1.setBackgroundColor(Color.GRAY);
        ansButton2.setBackgroundColor(Color.GRAY);
        ansButton3.setBackgroundColor(Color.GRAY);
    }

    private void Checker(int choice, Button click){

        ansButton1.setBackgroundColor(Color.GRAY);
        ansButton2.setBackgroundColor(Color.GRAY);
        ansButton3.setBackgroundColor(Color.GRAY);

        if (answered == page)
            return;

        answered += 1;
        int index = page - 1;
        if (CorrectAnswers.get(index)[choice] == 1){
            score += 1;
            click.setBackgroundColor(Color.GREEN);
        }
        else {

            click.setBackgroundColor(Color.RED);

            if (CorrectAnswers.get(index)[0] == 1)
                ansButton1.setBackgroundColor(Color.GREEN);
            if (CorrectAnswers.get(index)[1] == 1)
                ansButton2.setBackgroundColor(Color.GREEN);
            if (CorrectAnswers.get(index)[2] == 1)
                ansButton3.setBackgroundColor(Color.GREEN);
        }
    }
}
