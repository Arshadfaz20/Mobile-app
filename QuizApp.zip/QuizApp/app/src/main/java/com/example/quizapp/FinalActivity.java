package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class FinalActivity extends AppCompatActivity {

    int score;
    int maxQuestions;
    String playerName;
    TextView congratsText;
    TextView scoreText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        congratsText = findViewById(R.id.textViewCongrats);
        scoreText = findViewById(R.id.textViewScore);

        Intent intent = getIntent();
        score = intent.getIntExtra("Score", 0);
        maxQuestions = intent.getIntExtra("MaxQuestions", 0);
        playerName = intent.getStringExtra("Name");

        congratsText.setText("Congratulations " + playerName + "!");
        scoreText.setText(score + "/" + maxQuestions);
    }

    public void OnClickRestart(View view) {
        finish();
    }

    public void OnClickFinish(View view) {
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }
}
