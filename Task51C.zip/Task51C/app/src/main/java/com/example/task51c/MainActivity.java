package com.example.task51c;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.MediaRouteButton;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  implements com.example.task51c.VerticalAdapter.OnRowClickListener{

    RecyclerView recyclerView1, recyclerView2;
    HorizontalAdapter horizontalAdapterView;
    VerticalAdapter verticalAdapterView;

    List<TopDestinations> HorizontalList = new ArrayList<>();
    Integer[] imageListH = {R.drawable.dubai, R.drawable.colombo, R.drawable.kualalampur, R.drawable.sydney, R.drawable.paris};

    List<PlacesToGo> VerticalList = new ArrayList<>();
    Integer[] imageListV = {R.drawable.dubai, R.drawable.colombo, R.drawable.kualalampur, R.drawable.sydney, R.drawable.paris};
    String[] destNameList = {"Dubai", "Colombo", "Kuala Lampur", "Sydney", "Paris"};
    String[] destDescripList = {"Visit Dubai and explore the city",
            "Visit Colombo and explore the city",
            "Visit Kuala Lampur and explore the city",
            "Visit Sydney and explore the city",
            "Visit Paris and explore the city",
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView1 = findViewById(R.id.recyclerView1);
        horizontalAdapterView = new HorizontalAdapter(HorizontalList, this);
        recyclerView1.setAdapter(horizontalAdapterView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView1.setLayoutManager(layoutManager);
        layoutManager.setOrientation(RecyclerView.HORIZONTAL);
        for (int i = 0; i < imageListH.length; i++) {
            com.example.task51c.TopDestinations horizontal = new com.example.task51c.TopDestinations(i, imageListH[i]);
            HorizontalList.add(horizontal);
        }

        recyclerView2 = findViewById(R.id.recyclerView2);
        verticalAdapterView = new VerticalAdapter(VerticalList, MainActivity.this.getApplicationContext(),  this);
        recyclerView2.setAdapter(verticalAdapterView);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));

        for (int i = 0; i < imageListV.length; i++) {
            com.example.task51c.PlacesToGo vertical = new com.example.task51c.PlacesToGo(i, imageListV[i], destNameList[i], destDescripList[i]);
            VerticalList.add(vertical);
        }
    }
    @Override
    public void onItemClick(int position) {
        Fragment fragment;
        switch (position){
            case 0:
                //Toast.makeText(this,"clicked",Toast.LENGTH_SHORT).show();
                fragment = new FragDubai();
                break;
            case 1:
                fragment = new FragCmb();
                break;
            case 2:
                fragment = new FragKL();
                break;
            case 3:
                fragment = new FragSyd();
                break;
            case 4:
                fragment = new FragParis();
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + position);
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment, fragment).commit();
    }
}