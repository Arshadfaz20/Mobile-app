package com.example.task21p;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
 import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton tempButton;
    ImageButton weightButton;
    ImageButton lengthButton;
    TextView resultViewText1;
    TextView resultViewText2;
    TextView resultViewText3;
    EditText editText1;
    float number, value1,value2,value3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner mySpinner = findViewById(R.id.spinner);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        editText1 = findViewById(R.id.editText1);
        tempButton = findViewById(R.id.tempButton);
        weightButton = findViewById(R.id.weightButton);
        lengthButton = findViewById(R.id.lengthButton);
        resultViewText1 = findViewById(R.id.resultTextView1);
        resultViewText2 = findViewById(R.id.resultTextView2);
        resultViewText3 = findViewById(R.id.resultTextView3);

        tempButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mySpinner.getSelectedItem().toString().equals("Celsius")) {

                    double result1 = Double.parseDouble(editText1.getText().toString()) * 9/5 + 32;
                    double result2 = Double.parseDouble(editText1.getText().toString()) + 273.15;

                    resultViewText1.setText(Double.toString(result1) + " Fahrenheit");
                    resultViewText2.setText(Double.toString(result2) + " Kelvin");
                    resultViewText3.setText("");
                } else {
                    resultViewText1.setText("No result");
                    resultViewText2.setText("No result");
                    resultViewText3.setText("No result");

                    Toast.makeText(MainActivity.this, "Select the correct icon to convert", Toast.LENGTH_LONG).show();

                }

            }
        });

        weightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mySpinner.getSelectedItem().toString().equals("Kilogram"))
                {
                    double result1 = Double.parseDouble(editText1.getText().toString()) * 100;
                    double result2 = Double.parseDouble(editText1.getText().toString()) * 35.274;
                    double result3 = Double.parseDouble(editText1.getText().toString()) * 2.205;

                    resultViewText1.setText(Double.toString(result1) + " Grams");
                    resultViewText2.setText(Double.toString(result2) + " Ounces");
                    resultViewText3.setText(Double.toString(result3) + " Pounds");
                }
                else
                {
                    resultViewText1.setText("No result");
                    resultViewText2.setText("No result");
                    resultViewText3.setText("No result");

                    Toast.makeText( MainActivity.this ,  "Select the correct icon to convert",Toast.LENGTH_LONG).show();
                }

            }
        });

        lengthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mySpinner.getSelectedItem().toString().equals("Metre") )
                {
                    double result1 = Double.parseDouble(editText1.getText().toString()) * 100;
                    double result2 = Double.parseDouble(editText1.getText().toString()) * 3.281;
                    double result3 = Double.parseDouble(editText1.getText().toString()) * 39.37;

                    resultViewText1.setText(Double.toString(result1) + " Centimeter");
                    resultViewText2.setText(Double.toString(result2) + " Foot");
                    resultViewText3.setText(Double.toString(result3) + " Inch");
                }
                else
                {
                    resultViewText1.setText("No result");
                    resultViewText2.setText("No result");
                    resultViewText3.setText("No result");

                    Toast.makeText( MainActivity.this ,  "Select the correct icon to convert",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}