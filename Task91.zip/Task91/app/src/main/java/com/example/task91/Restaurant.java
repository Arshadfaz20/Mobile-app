package com.example.task91;

import android.app.Application;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class Restaurant extends Application {

    private ArrayList<String> restaurants = new ArrayList<>();
    private ArrayList<LatLng> locations = new ArrayList<>();

    public void setRestaurants(ArrayList<String> restaurants) {
        this.restaurants = restaurants;
    }

    public ArrayList<String> getRestaurants() {
        return restaurants;
    }

    public ArrayList<LatLng> getLocations() {
        return locations;
    }

    public void setLocations(ArrayList<LatLng> locations) {
        this.locations = locations;
    }
}
