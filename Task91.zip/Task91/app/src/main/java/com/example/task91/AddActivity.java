package com.example.task91;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;


import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class AddActivity extends AppCompatActivity implements LocationListener{

    LocationManager locationManager;
//    LocationListener locationListener;
    EditText placeText, locationText;
    Button getlocButton, saveButton , goButton;
    List<Address> addresses;
    double lat,log;
    String name;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        placeText = findViewById(R.id.placeText);
        locationText = findViewById(R.id.locationText);
        getlocButton = findViewById(R.id.getlocButton);
        saveButton = findViewById(R.id.saveButton);
        goButton = findViewById(R.id.goButton);

        Places.initialize(getApplicationContext(),"AIzaSyC6KrjzWHVgeOWYUQqNxpmxWfzrHtnmNDk");

        locationText.setFocusable(false);
        locationText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS,Place.Field.LAT_LNG,Place.Field.NAME);

                Intent intent1 = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY,fieldList).build(AddActivity.this);
                startActivityForResult(intent1,100);
            }
        });


        if(ContextCompat.checkSelfPermission(AddActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(AddActivity.this,new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            },100);
        }

    }

    @SuppressLint("MissingPermission")
    private void getLocation()
    {
        try
        {
            locationManager  = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,5,AddActivity.this);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        Toast.makeText(this, "" + location.getLatitude()+","+ location.getLongitude(), Toast.LENGTH_SHORT).show();
        lat =  location.getLatitude();
        log =  location.getLongitude();

        try
        {
            Geocoder geocoder = new Geocoder(AddActivity.this, Locale.getDefault());
            addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
            String address = addresses.get(0).getAddressLine(0);

            locationText.setText(address);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {

    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
    }


    public void onClickSave (View v) {
        if(name!=null && lat!=0 &&log!=0)
        {
            DatabaseClass db = new DatabaseClass(AddActivity.this);
            db.addLocation(name,lat,log);
            finish();
        }

        else
        {
            Toast.makeText(AddActivity.this, "Both Fields are Empty", Toast.LENGTH_SHORT).show();
        }

    }

    public void onClickloc(View v) {
        getLocation();
    }

    public void map(View v) {
        name = placeText.getText().toString();
        Intent intent = new Intent(AddActivity.this,MapsActivity.class);
        intent.putExtra("latitude",lat);
        intent.putExtra("longitude",log);
        intent.putExtra("place",name);
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK)
        {
            Place place = Autocomplete.getPlaceFromIntent(data);
            locationText.setText(place.getAddress());
            placeText.setText(place.getName());

            lat = place.getLatLng().latitude;
            log = place.getLatLng().longitude;
            name = place.getName();
        }

        else if (resultCode == AutocompleteActivity.RESULT_ERROR)
        {
            Status status = Autocomplete.getStatusFromIntent(data);
            Toast.makeText(getApplicationContext(),status.getStatusMessage(),Toast.LENGTH_SHORT).show();
        }
    }



}