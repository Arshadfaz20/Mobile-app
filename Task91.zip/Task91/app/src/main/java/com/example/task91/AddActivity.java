package com.example.task91;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;

public class AddActivity extends AppCompatActivity {

    LatLng current_location = new LatLng(0,0);
    String current_rest = "empty";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Button getlocButton = (Button)findViewById(R.id.getlocButton);
        Button showButton = (Button)findViewById(R.id.showButton);
        Button saveButton = (Button)findViewById(R.id.saveButton);
        TextView placeText = (TextView)findViewById(R.id.placeText);
        TextView locationText = (TextView)findViewById(R.id.locationText);

        current_rest = getIntent().getStringExtra("NAME");
        current_location = getIntent().getParcelableExtra("LOCATION");


        if (current_rest != null){
            if(current_location != null){
                placeText.setText(current_rest);
                double lat = current_location.latitude;
                double lon = current_location.longitude;
                locationText.setText(lat + " , " + lon);
            }

        }

    }

    public void onClickGet(View v){
        Intent intent = new Intent(AddActivity.this, SearchActivity.class);
        startActivity(intent);
        finish();
    }

    public void onClickGo(View v){
        Bundle args = new Bundle();
        args.putParcelable("SHOW_LOCATION", current_location);
        args.putString("SHOW_MARKER", current_rest);
        Intent intent = new Intent(AddActivity.this, ShowMapActivity.class);
        intent.putExtras(args);
        startActivity(intent);
    }

    public void onClickSave(View v){
        Bundle args = new Bundle();
        args.putParcelable("location", current_location);
        args.putString("marker", current_rest);

        Intent intent = new Intent(AddActivity.this, MainActivity.class);
        intent.putExtras(args);
        startActivity(intent);
    }
}