package com.example.task91;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    Button button,button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.addButton);
        button2 = findViewById(R.id.showButton);

    }

    public void onClickAdd(View view) {
        Intent intent = new Intent(MainActivity.this,AddActivity.class);
        startActivity(intent);
    }
    public void onClickShow(View view) {
        Intent intent2 = new Intent(MainActivity.this,ShowMapActivity.class);
        startActivity(intent2);
    }

}



