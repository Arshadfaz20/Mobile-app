package com.example.task91;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> markers = new ArrayList<String>();
    private ArrayList<LatLng> location = new ArrayList<LatLng>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        location = ((Restaurant) getApplication()).getLocations();
        markers = ((Restaurant) getApplication()).getRestaurants();

        String current_rest = getIntent().getStringExtra("marker");
        markers.add(current_rest);
        LatLng current_location = getIntent().getParcelableExtra("location");
        location.add(current_location);

        ((Restaurant) getApplication()).setRestaurants(markers);
        ((Restaurant) getApplication()).setLocations(location);

    }

    public void onClickAdd(View v){
        Intent intent = new Intent(MainActivity.this, AddActivity.class);
        startActivity(intent);
    }

    public void onClickShow(View v){
        Intent intent = new Intent(MainActivity.this, MapsActivity.class);
        startActivity(intent);
    }


}
