package com.example.a61food;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;

import com.example.a61food.data.DatabaseHelper;
import com.example.a61food.model.Food;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    private static final String TAG = "CHECKING USER ID";
    RecyclerView recyclerView;
    com.example.a61food.Adapter adapter;
    List<Food> foodList;
    List<Food> myFoodList;
    DatabaseHelper db;
    ImageButton addButton;
    int user_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Intent intent = getIntent();
        user_ID = intent.getIntExtra("USER_ID", 0);
        recyclerView = findViewById(R.id.foodRecyclerView);
        foodList = new ArrayList<>();
        myFoodList = new ArrayList<>();

        db = new DatabaseHelper(this);
        fetchAllFoodItemsFromDatabase();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter(this, ListActivity.this, myFoodList);
        recyclerView.setAdapter(adapter);

        addButton = findViewById(R.id.addMyFoodbtn);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListActivity.this, AddActivity.class);
                intent.putExtra("USER_ID", user_ID);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            recreate();
        }
    }

    public void showMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.menu);
        popupMenu.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.home_id:
                Intent intent = new Intent(ListActivity.this, HomeActivity.class);
                intent.putExtra("USER_ID", user_ID);
                startActivity(intent);
                return true;

            case R.id.account_id:

            case R.id.list_id:
                Intent intent2 = new Intent(ListActivity.this, ListActivity.class);
                intent2.putExtra("USER_ID", user_ID);
                startActivity(intent2);
                return true;

            default:
                return false;
        }
    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
    }

    void fetchAllFoodItemsFromDatabase() {
        foodList = db.getAllFoodItems();
        for(int i = 0; i < foodList.size(); i++)
        {
            if(user_ID == foodList.get(i).getUser_id()){
                myFoodList.add(foodList.get(i));
            }
        }
    }
}