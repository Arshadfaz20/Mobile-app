package com.example.a61food;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.a61food.data.DatabaseHelper;
import com.example.a61food.model.Food;

public class AddActivity extends AppCompatActivity {
    EditText food_title, food_description,time_added,food_quantity,location;
    CalendarView calendarView;
    ImageView food_image;
    Button saveButton;
    String date;
    int PICK_IMAGE_REQUEST = 100;
    Uri imageFilePath;
    Bitmap imageToStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        food_image = findViewById(R.id.foodImage);
        food_title = findViewById(R.id.titleEdit);
        food_description = findViewById(R.id.descEdit);
        calendarView = findViewById(R.id.calendarView);
        time_added = findViewById(R.id.timeEdit);
        food_quantity = findViewById(R.id.quantityEdit);
        location = findViewById(R.id.locationEdit);
        saveButton = findViewById(R.id.saveFoodbtn);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                        date = dayOfMonth + "/" + (month+1) + "/" + year;
                    }
                });

                if (TextUtils.isEmpty(food_title.getText().toString()))
                {
                    Toast.makeText(AddActivity.this, "Title Field is Empty", Toast.LENGTH_SHORT).show();
                }

                else if (TextUtils.isEmpty(food_description.getText().toString()))
                {
                    Toast.makeText(AddActivity.this, "Description Field is Empty", Toast.LENGTH_SHORT).show();
                }
                else if (date == null)
                {
                    Toast.makeText(AddActivity.this, "Date Field is Empty", Toast.LENGTH_SHORT).show();
                }

                else if (TextUtils.isEmpty(time_added.getText().toString()))
                {
                    Toast.makeText(AddActivity.this, "Time Field is Empty", Toast.LENGTH_SHORT).show();
                }

                else if ( TextUtils.isEmpty(food_quantity.getText().toString()))
                {
                    Toast.makeText(AddActivity.this, "Quantity Field is Empty", Toast.LENGTH_SHORT).show();
                }

                else if (TextUtils.isEmpty(location.getText().toString()))
                {
                    Toast.makeText(AddActivity.this, "Location Field is Empty", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent intent1 = getIntent();
                    int user_Id = intent1.getIntExtra("USER_ID",0);
                    DatabaseHelper db = new DatabaseHelper(AddActivity.this);
                    db.insertFoodItem(new Food(user_Id, imageToStore,food_title.getText().toString(),food_description.getText().toString(),date,time_added.getText().toString(),food_quantity.getText().toString(),location.getText().toString()));
                    Intent intent = new Intent(AddActivity.this, HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    public void chooseImage(View objectView)
    {
        try
        {
            confirmDialog();
        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try
        {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data!=null && data.getData()!=null);
            {
                imageFilePath = data.getData();
                imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(),imageFilePath);

                food_image.setImageBitmap(imageToStore);
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }


    void confirmDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Allow the app to access photos,media and files on your device?");
        builder.setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Intent objectIntent = new Intent();
                objectIntent.setType("image/*");

                objectIntent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);

            }
        });

        builder.setNegativeButton("DENY", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();
    }
}