package com.example.a61food;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.a61food.data.DatabaseHelper;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText userEdit, passwordEdit;
    Button loginButton, signUpButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userEdit = findViewById(R.id.userEdit);
        passwordEdit = findViewById(R.id.passEdit);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);
        db = new DatabaseHelper(this);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean result = db.fetchUser(userEdit.getText().toString(), passwordEdit.getText().toString());
                int user_id =  db.fetchUserID(userEdit.getText().toString());
                if(result) {
                    Toast.makeText(MainActivity.this, "Successfully Logged In, User ID: " + user_id, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("USER_ID", user_id);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this, "User Does not Exist", Toast.LENGTH_SHORT).show();
                }
            }
        });
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });
    }
}