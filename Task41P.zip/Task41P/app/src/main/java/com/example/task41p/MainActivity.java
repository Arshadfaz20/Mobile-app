package com.example.task41p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    TextView textViewNotif, textViewEnter;
    ImageButton playButton, pauseButton, stopButton;
    EditText editTextWorkout;
    Chronometer chronometer;
    SharedPreferences sharedPreferences;

    int seconds, minutes;
    String workout, prevWorkout, prevTime;
    boolean working;
    long timePause, timeCurrent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewNotif = findViewById(R.id.textViewNotif);
        textViewEnter = findViewById(R.id.textViewEnter);
        playButton = findViewById(R.id.playButton);
        pauseButton = findViewById(R.id.pauseButton);
        stopButton = findViewById(R.id.stopButton);
        editTextWorkout = findViewById(R.id.editTextWorkout);
        chronometer = findViewById(R.id.chronometer);

        textViewNotif.setText(prevWorkout);
    }

    public void showTime() {

        timeCurrent = SystemClock.elapsedRealtime() - chronometer.getBase();
        seconds = (int) (timeCurrent / 1000) % 60;
        minutes = (int) (timeCurrent / 1000) / 60;
        prevTime = String.format("%02d:%02d", minutes, seconds);
    }

    public void update() {

        SharedPreferences sharedPreferences = getSharedPreferences("timer", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("PW", prevWorkout);
        editor.commit();
    }

    public void onClickPlay(View view) {

        if (!working) {
            working = true;
            chronometer.setBase(SystemClock.elapsedRealtime() - timePause);
            chronometer.start();
        }
    }

    public void onClickPause(View view) {

        if (working) {
            chronometer.stop();
            timePause = SystemClock.elapsedRealtime() - chronometer.getBase();
            working = false;
        }
    }

    public void onClickStop(View view) {
        workout = editTextWorkout.getText().toString();
        showTime();
        prevWorkout = String.format("You spent %s on %s last time.", prevTime, workout);

        textViewNotif.setText(prevWorkout);
        update();
        chronometer.setBase(SystemClock.elapsedRealtime());
        timePause = 0;
        working = false;
        chronometer.stop();
    }

}
