package com.example.task81;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText URLeditText;
    Button playButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        URLeditText = findViewById(R.id.URLeditText);
        playButton = findViewById(R.id.playButton);
    }

    public void onClickPlay(View view) {

        String url = URLeditText.getText().toString();
        Intent intent = new Intent(this, Player.class);
        intent.putExtra(YouTubeConfig.URL_KEY, url);
        startActivity(intent);
    }
}