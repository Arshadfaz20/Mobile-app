package com.example.task81;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class YouTubeConfig {

    public static final String API_KEY = "AIzaSyBX1WbQU7TThiDBk3CuGYH0Wh17w1Hml48";
    public static final String URL_KEY = "url";

    public static String getAPIKey() {
        return API_KEY;
    }
}