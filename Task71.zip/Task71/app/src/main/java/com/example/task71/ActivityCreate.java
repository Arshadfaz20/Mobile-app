package com.example.task71;

import android.app.AppComponentFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task71.data.DatabaseHelper;
import com.example.task71.model.Note;

public class ActivityCreate extends AppCompatActivity {

    DatabaseHelper db;
    Button saveButton;
    EditText labelEditText, noteEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        db = new DatabaseHelper(this);
        saveButton = findViewById(R.id.saveButton);
        labelEditText = findViewById(R.id.labelEditText);
        noteEditText = findViewById(R.id.noteEditText);
    }

    public void onClickSave(View view) {
        String name = labelEditText.getText().toString();
        String content = noteEditText.getText().toString();

        long result = db.insertNote(new Note(name, content));
        if (result != 0){
            Toast.makeText(ActivityCreate.this, "Note created!", Toast.LENGTH_SHORT).show();
            finish();
        }
        else
        {
            Toast.makeText(ActivityCreate.this, "ERROR; Could not create note :(", Toast.LENGTH_SHORT).show();
        }
    }

}