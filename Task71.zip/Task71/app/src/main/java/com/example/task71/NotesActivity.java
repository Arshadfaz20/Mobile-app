package com.example.task71;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task71.data.DatabaseHelper;
import com.example.task71.model.Note;
import com.example.task71.model.NoteAdapter;

import java.util.List;

public class NotesActivity extends AppCompatActivity implements NoteAdapter.OnRowClickListener{
    private RecyclerView notes_recycler;
    private NoteAdapter notesAdapter;
    private List<Note> notes_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        DatabaseHelper db = new DatabaseHelper(this);
        notes_list = db.fetchNotes();

        notes_recycler = findViewById(R.id.notesRecycler);
        notesAdapter = new NoteAdapter(notes_list, NotesActivity.this.getApplicationContext(), this);
        notes_recycler.setAdapter(notesAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        notes_recycler.setLayoutManager(layoutManager);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(NotesActivity.this, UpdateNotes.class);
        intent.putExtra("current_note_name", notes_list.get(position).getName());
        intent.putExtra("current_note_content", notes_list.get(position).getContent());
        startActivity(intent);
        finish();
    }
}