package com.example.task71;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task71.data.DatabaseHelper;
import com.example.task71.model.Note;

public class UpdateNotes extends AppCompatActivity {

    DatabaseHelper db;
    String note_name, note_content, updated_name, updated_content;
    Note note;

    EditText updateName, updateContent;
    Button updateButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_notes);

        db = new DatabaseHelper(this);
        updateName = findViewById(R.id.updateName);
        updateContent = findViewById(R.id.updateContent);
        updateButton = findViewById(R.id.deleteButton);
        deleteButton = findViewById(R.id.updateButton);

        note_name = getIntent().getStringExtra("current_note_name");
        note_content = getIntent().getStringExtra("current_note_content");
        Toast.makeText(UpdateNotes.this, "note_name" + note_name, Toast.LENGTH_SHORT).show();
        note = new Note(note_name, note_content);

        updateName.setText(note.getName());
        updateContent.setText(note.getContent());
    }

    public void onClickUpdate(View v){

        EditText updated_name_edit = findViewById(R.id.updateName);
        EditText updated_content_edit = findViewById(R.id.updateContent);
        updated_name = updated_name_edit.getText().toString();
        updated_content = updated_content_edit.getText().toString();
        Note updated_note = new Note(updated_name, updated_content);

        boolean done = db.updateNote(updated_note);

        if (done == true) {
            Toast.makeText(UpdateNotes.this, "Successfully updated!", Toast.LENGTH_SHORT).show();
            finish();
        }
        else
        {
            Toast.makeText(UpdateNotes.this, "ERROR: Could not update", Toast.LENGTH_SHORT).show();
        }

    }

    public void onClickDelete(View v) {
        db.deleteNote(note);
        finish();
    }
}