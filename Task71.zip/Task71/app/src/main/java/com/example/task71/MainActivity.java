package com.example.task71;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button showButton, createButton;
    ImageView noteImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createButton = findViewById(R.id.createButton);
        showButton = findViewById(R.id.showButton);
        noteImage =  findViewById(R.id.noteImage);
    }

    public void onClickCreate(View view) {
        Intent intent = new Intent(MainActivity.this, ActivityCreate.class);
        startActivity(intent);
    }

    public void onClickShow(View view) {
        Intent intent = new Intent(MainActivity.this, NotesActivity.class);
        startActivity(intent);
    }
}