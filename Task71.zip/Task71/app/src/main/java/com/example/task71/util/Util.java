package com.example.task71.util;

public class Util {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "note_db";
    public static final String TABLE_NAME = "notes";

    public static final String NOTE_ID = "note_id";
    public static final String NOTE_NAME = "note_name";
    public static final String NOTE_CONTENT = "note_content";
}